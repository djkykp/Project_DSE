/* generated configuration header file - do not edit */
#ifndef R_ICU_CFG_H_
#define R_ICU_CFG_H_
#define ICU_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* R_ICU_CFG_H_ */
