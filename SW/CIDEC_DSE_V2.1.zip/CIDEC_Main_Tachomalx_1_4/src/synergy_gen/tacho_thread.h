/* generated thread header file - do not edit */
#ifndef TACHO_THREAD_H_
#define TACHO_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
extern "C" void tacho_thread_entry(void);
#else
extern void tacho_thread_entry(void);
#endif
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* TACHO_THREAD_H_ */
