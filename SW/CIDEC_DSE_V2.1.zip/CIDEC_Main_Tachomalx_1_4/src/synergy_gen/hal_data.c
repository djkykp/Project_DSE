/* generated HAL source file - do not edit */
#include "hal_data.h"
#if (0) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_timer2) && !defined(SSP_SUPPRESS_ISR_GPT1)
SSP_VECTOR_DEFINE_CHAN(gpt_counter_overflow_isr, GPT, COUNTER_OVERFLOW, 1);
#endif
#endif
static gpt_instance_ctrl_t g_timer2_ctrl;
static const timer_on_gpt_cfg_t g_timer2_extend = { .gtioca = {
		.output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW }, .gtiocb = {
		.output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
		.shortest_pwm_signal = GPT_SHORTEST_LEVEL_OFF, };
static const timer_cfg_t g_timer2_cfg = { .mode = TIMER_MODE_PERIODIC, .period =
		1000, .unit = TIMER_UNIT_PERIOD_MSEC, .duty_cycle = 50,
		.duty_cycle_unit = TIMER_PWM_UNIT_RAW_COUNTS, .channel = 1, .autostart =
				true, .p_callback = timer_end2, .p_context = &g_timer2,
		.p_extend = &g_timer2_extend, .irq_ipl = (0), };
/* Instance structure to use this module. */
const timer_instance_t g_timer2 = { .p_ctrl = &g_timer2_ctrl, .p_cfg =
		&g_timer2_cfg, .p_api = &g_timer_on_gpt };
#if (0) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_timer1) && !defined(SSP_SUPPRESS_ISR_GPT0)
SSP_VECTOR_DEFINE_CHAN(gpt_counter_overflow_isr, GPT, COUNTER_OVERFLOW, 0);
#endif
#endif
static gpt_instance_ctrl_t g_timer1_ctrl;
static const timer_on_gpt_cfg_t g_timer1_extend = { .gtioca = {
		.output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW }, .gtiocb = {
		.output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
		.shortest_pwm_signal = GPT_SHORTEST_LEVEL_OFF, };
static const timer_cfg_t g_timer1_cfg = { .mode = TIMER_MODE_PERIODIC, .period =
		1000, .unit = TIMER_UNIT_PERIOD_MSEC, .duty_cycle = 50,
		.duty_cycle_unit = TIMER_PWM_UNIT_RAW_COUNTS, .channel = 0, .autostart =
				true, .p_callback = timer_end0, .p_context = &g_timer1,
		.p_extend = &g_timer1_extend, .irq_ipl = (0), };
/* Instance structure to use this module. */
const timer_instance_t g_timer1 = { .p_ctrl = &g_timer1_ctrl, .p_cfg =
		&g_timer1_cfg, .p_api = &g_timer_on_gpt };
#if (2) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_timer0) && !defined(SSP_SUPPRESS_ISR_GPT7)
SSP_VECTOR_DEFINE_CHAN(gpt_counter_overflow_isr, GPT, COUNTER_OVERFLOW, 7);
#endif
#endif
static gpt_instance_ctrl_t g_timer0_ctrl;
static const timer_on_gpt_cfg_t g_timer0_extend = { .gtioca = {
		.output_enabled = true, .stop_level = GPT_PIN_LEVEL_LOW }, .gtiocb = {
		.output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
		.shortest_pwm_signal = GPT_SHORTEST_LEVEL_OFF, };
static const timer_cfg_t g_timer0_cfg = { .mode = TIMER_MODE_PWM, .period = 2,
		.unit = TIMER_UNIT_PERIOD_USEC, .duty_cycle = 50, .duty_cycle_unit =
				TIMER_PWM_UNIT_PERCENT, .channel = 7, .autostart = true,
		.p_callback = NULL, .p_context = &g_timer0,
		.p_extend = &g_timer0_extend, .irq_ipl = (2), };
/* Instance structure to use this module. */
const timer_instance_t g_timer0 = { .p_ctrl = &g_timer0_ctrl, .p_cfg =
		&g_timer0_cfg, .p_api = &g_timer_on_gpt };
void g_hal_init(void) {
	g_common_init();
}
