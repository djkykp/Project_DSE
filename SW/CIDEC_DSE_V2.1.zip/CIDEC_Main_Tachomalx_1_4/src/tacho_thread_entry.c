#include "tacho_thread.h"
#include "lcd.h"
//#include "lcd_setup.c"
#include "weather_GNU_resources.h"
#include "weather_GNU_specifications.h"
//#include "hmi_thread.c"




void tacho_thread_entry(void) {
	/* TODO: add your own code here */



        tx_thread_sleep(10);

}
