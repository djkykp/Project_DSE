/* HAL-only entry function */
#include "hal_data.h"
#include "gx_api.h"
#include "sf_message_payloads.h"
#include "rpm_reader_api.h"
#include "button_thread0.h"
#include <stdio.h>
#include <math.h>
#include "bsp_cfg.h"
#include "globals.h"
#include "hmi_thread.h"
#include "gx_api.h"
#include"sf_message_api.h"
#include "weather_GNU_resources.h"
#include "weather_GNU_specifications.h"
#include "lcd.h"
/***********************************************************************************************************************
 * Exported global functions (to be accessed by other files)
 **********************************************************************************************************************/
extern const sf_message_post_cfg_t g_post_cfg;
extern const sf_message_acquire_cfg_t g_acquire_cfg;



GX_EVENT gxe;


void hal_entry(void) {
	/* TODO: add your own code here */

}

void timer_end0(timer_callback_args_t *p_args){//function called every time timer 1 period elapses (1 sec)



	UINT        status;
		    GX_PROMPT * p_prompt;
		    bool send_event = true;
		        GX_EVENT gxe;
		//g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_14, on);


		float temp_in_C = 0;
		    ssp_err_t err;


		    /** Send event. */
		                sf_message_header_t * p_message  = NULL;
		                sf_message_payload_t * p_payload = NULL;

		    /** Get buffer from messaging framework. */
		                err = g_sf_message.p_api->bufferAcquire(g_sf_message.p_ctrl, (sf_message_header_t **) &p_message, &g_acquire_cfg, TX_NO_WAIT);


		 /** Create message. */
		            p_message->event_b.class_code = SF_MESSAGE_EVENT_CLASS_RPM_READER;
		            p_message->event_b.code  =SF_MESSAGE_EVENT_READ_RPM;
		            //p_payload = (sf_message_payload_t*)(p_message+1);
		            //p_payload->rpm_reader_payload.rpm = 101.00;

		            /** Post message. */
		            sf_message_post_err_t post_err;
		            err = g_sf_message.p_api->post(g_sf_message.p_ctrl, (sf_message_header_t *) p_message, &g_post_cfg, &post_err, TX_NO_WAIT);




g_timer1.p_api->periodSet (g_timer1.p_ctrl, 1000, TIMER_UNIT_PERIOD_MSEC);
	}


void timer_end3(timer_callback_args_t *p_args){

	UINT        status;
		    GX_PROMPT * p_prompt;
		    bool send_event = true;
		        GX_EVENT gxe;
		//g_ioport.p_api->pinWrite(IOPORT_PORT_00_PIN_05, true);
		           //on=!on;

		float temp_in_C = 0;
		    ssp_err_t err;


		    /** Send event. */
		                sf_message_header_t * p_message  = NULL;
		                sf_message_payload_t * p_payload = NULL;

		    /** Get buffer from messaging framework. */
		                err = g_sf_message.p_api->bufferAcquire(g_sf_message.p_ctrl, (sf_message_header_t **) &p_message, &g_acquire_cfg, TX_NO_WAIT);


		 /** Create message. */
		            //p_message->event_b.class_code = SF_MESSAGE_EVENT_CLASS_RPM_READER;
		           // p_message->event_b.code  =SF_MESSAGE_EVENT_PWM_DUTY_CYCLE_UPDATE ;

		            /** Post message. */
		            sf_message_post_err_t post_err;
		            err = g_sf_message.p_api->post(g_sf_message.p_ctrl, (sf_message_header_t *) p_message, &g_post_cfg, &post_err, TX_NO_WAIT);





	g_timer3.p_api->periodSet (g_timer3.p_ctrl, 1, TIMER_UNIT_PERIOD_SEC);



}



