/* HMI Thread entry function */
#include "globals.h"
#include "hmi_thread.h"
#include "pwm_thread0.h"
#include "button_thread0.h"
#include "button_thread0.h"
#include "gx_api.h"
#include <math.h>
#include"sf_message_api.h"
#include "rpm_reader_api.h"
#include "sf_message_payloads.h"
#if defined ( __GNUC__ )
#include "weather_GNU_resources.h"
#include "weather_GNU_specifications.h"
#elif defined ( __ICCARM__ )
#include "..\guix_gen\IAR\weather_IAR_resources.h"
#include "..\guix_gen\IAR\weather_IAR_specifications.h"
#endif
 #define CLOCK_A         0
  #define CLOCK_B         1

#if defined(BSP_BOARD_S7G2_SK)||defined(BSP_BOARD_S5D9_PK)
 
#if defined ( __GNUC__ )
#include "lcd.h"
#elif defined ( __ICCARM__ )
#include "..\guix\lcd.h"
#endif
#endif
GX_PROMPT   * prompt;
GX_WINDOW_ROOT * p_window_root;

int rpm_pwm_duty=99000;
int rpm_duty_copy=0;
double K=9;   //Proportional constant *********************
double IK=0.00123;   //Integrative Term constant
double IT,IT0=0;

static GX_CHAR rpm_error_string[10];
static GX_CHAR prop_term_string[10];
static GX_CHAR integrative_term_string[10];
static GX_CHAR current_rpm_string[10];
static GX_CHAR rpm_pwm_duty_string[10];


#if defined(BSP_BOARD_S7G2_SK)||defined(BSP_BOARD_S5D9_PK)
void g_lcd_spi_callback(spi_callback_args_t * p_args);
#endif
void hmi_thread_main(void);
static void hmi_send_touch_message(sf_touch_panel_payload_t * p_payload);


/** Post options are generally the same in this project, so store them once. */
const sf_message_post_cfg_t g_post_cfg =
{
    .priority = SF_MESSAGE_PRIORITY_NORMAL,
    .p_callback = NULL,
};

/** Acquire options are generally the same in this project, so store them once. */
const sf_message_acquire_cfg_t g_acquire_cfg =
{
    .buffer_keep = false,
};


void hmi_thread_main(void)
{


	                    	gx_prompt_text_set(&main_screen.main_screen_duty_cycle_adviser,"");

    ssp_err_t err;
    UINT      status = TX_SUCCESS;
    sf_message_header_t * p_message = NULL;

    /* Initializes GUIX. */
    status = gx_system_initialize();
    if(TX_SUCCESS != status)
    {
        while(1)
           {;}
    }

    /* Initializes GUIX drivers. */
    err = g_sf_el_gx0.p_api->open (g_sf_el_gx0.p_ctrl, g_sf_el_gx0.p_cfg);
    if(SSP_SUCCESS != err)
    {
        while(1)
            {;}
    }

    gx_studio_display_configure ( MAIN_DISPLAY,
                                  g_sf_el_gx0.p_api->setup,
                                  LANGUAGE_ENGLISH,
                                  MAIN_DISPLAY_THEME_1,
                                  &p_window_root );

    err = g_sf_el_gx0.p_api->canvasInit(g_sf_el_gx0.p_ctrl, p_window_root);
    if(SSP_SUCCESS != err)
    {
        while(1)
        {;}
    }

    /* Creates the primary screen. */
    status = gx_studio_named_widget_create("splash_screen",
                                           (GX_WIDGET *)p_window_root, GX_NULL);
    if(TX_SUCCESS != status)
    {
        while(1)
        {;}
    }

    /* Shows the root window to make it and patients screen visible. */
    status = gx_widget_show(p_window_root);
    if(TX_SUCCESS != status)
    {
        while(1)
        {;}
    }

    /* Lets GUIX run. */
    status = gx_system_start();
    if(TX_SUCCESS != status)
    {
        while(1)
        {;}
    }

#if defined(BSP_BOARD_S7G2_PE_HMI1)
    /* Controls the GPIO pin for LCD ON. */
    err = g_ioport.p_api->pinWrite(IOPORT_PORT_10_PIN_03, IOPORT_LEVEL_HIGH);
    if (err)
    {
        while(1)
        {;}
    }
#elif defined(BSP_BOARD_S7G2_DK)
    /* Controls the GPIO pin for LCD ON. */
    err = g_ioport.p_api->pinWrite(IOPORT_PORT_07_PIN_10, IOPORT_LEVEL_HIGH);
    if (err)
    {
        while(1)
        {;}
    }
#elif defined(BSP_BOARD_S7G2_SK)||defined(BSP_BOARD_S5D9_PK)
    /** Open the SPI driver to initialize the LCD **/
    err = g_spi_lcdc.p_api->open(g_spi_lcdc.p_ctrl, (spi_cfg_t *)g_spi_lcdc.p_cfg);

    /** Setup the ILI9341V **/
    ILI9341V_Init();
#endif

#if defined(BSP_BOARD_S7G2_PE_HMI1) || defined(BSP_BOARD_S7G2_DK)
    /* Opens PWM driver and controls the TFT panel back light. */
    err = g_pwm_backlight.p_api->open(g_pwm_backlight.p_ctrl, g_pwm_backlight.p_cfg);
    if (err)
    {
        while(1)
        {;}
    }
#endif
    //bool on=true;

    GX_EVENT gxe;


    while (1)
    {
        g_sf_message.p_api->pend(g_sf_message.p_ctrl, &hmi_thread_message_queue, (sf_message_header_t **) &p_message, TX_WAIT_FOREVER);
        switch (p_message->event_b.class_code)
        {
        case SF_MESSAGE_EVENT_CLASS_TOUCH:
            if (SF_MESSAGE_EVENT_NEW_DATA == p_message->event_b.code)
            {
                sf_touch_panel_payload_t * p_touch_message = (sf_touch_panel_payload_t *) p_message;

                /** Translate a touch event into a GUIX event */
                hmi_send_touch_message(p_touch_message);
            }

            if (SF_TOUCH_PANEL_EVENT_UP == p_message->event_b.code)
            	{

                       sf_touch_panel_payload_t * p_touch_message = (sf_touch_panel_payload_t *) SF_TOUCH_PANEL_EVENT_UP;

                       /** Translate a touch event into a GUIX event */
                       hmi_send_touch_message( p_touch_message );

                       }

            break;

        case SF_MESSAGE_EVENT_CLASS_RPM_READER:


                       if (SF_MESSAGE_EVENT_READ_RPM == p_message->event_b.code)
                       {


                    	rpm_current=rpm_current/4;
                        rpm_current=rpm_current*60;
                        rpm_error=(target_rpm-rpm_current);//error calculating
                        P=K*rpm_error;               //STEP = error and K product
                        IT=IK*rpm_error+IT0;

                        //PI CONTROL********************************************

                        if (rpm_error!=0)
                        {

                    	rpm_pwm_duty=rpm_pwm_duty-P-IT;


                    	//g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_14, on);
                    	//g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_14, true);
                    	}



                        if(rpm_pwm_duty>=99000){rpm_pwm_duty=99000;}
                        if(rpm_pwm_duty<=0){rpm_pwm_duty=5;}

                         //g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_14, false);

                        rpm_duty_copy=(99000-rpm_pwm_duty)/1000;

                        //PWM DUTY CYCLE UPDATE
                         g_timer0.p_api->dutyCycleSet(g_timer0.p_ctrl,rpm_pwm_duty, TIMER_PWM_UNIT_PERCENT_X_1000, CLOCK_B);

                         //rpm_pwm_duty=100-rpm_pwm_duty;
                         //DISPLAY SETTING
                         gx_prompt_text_set(&main_screen.main_screen_duty_percent, "%");
                         gx_prompt_text_set(&main_screen.main_screen_duty_text, "DUTY CYCLE");
                         gx_prompt_text_set(&main_screen.main_screen_duty_cycle_adviser, "");




                         //gx_progress_bar_value_set(&main_screen.main_screen_progress_bar, 1000);
                         //_gxe_radial_progress_bar_value_set(&main_screen.main_screen_progress_bar, 1000);
                         //snprintf("hola", sizeof("hola"), "%d", 102);
                         //gx_system_widget_find(ID_RPM_CURRENT, GX_SEARCH_DEPTH_INFINITE, (GX_WIDGET **) &prompt);
                         gx_utility_ltoa(rpm_pwm_duty, (GX_CHAR *)rpm_error_string, 10);
                         gx_prompt_text_set(&main_screen. main_screen_control_val, (GX_CHAR *)rpm_error_string);
                         //_gxe_prompt_text_set(GX_PROMPT *prompt, GX_CONST GX_CHAR *text);

                    	 gx_utility_ltoa(P, (GX_CHAR *)prop_term_string, 10);
                    	 gx_prompt_text_set(&main_screen.main_screen_p_term_display, (GX_CHAR *)prop_term_string);

                    	 gx_utility_ltoa(IT, (GX_CHAR *)integrative_term_string, 10);
                    	 gx_prompt_text_set(&main_screen.main_screen_i_term_display, (GX_CHAR *)integrative_term_string);

                         //RPM DISPLAY VALUE COLOR SELECCION
                    	if(rpm_current>=2500)
                    	  {
                          gx_prompt_text_color_set(&main_screen.main_screen_rpm_current_disp, GX_COLOR_ID_ID_RED,GX_COLOR_ID_ID_RED);
                    	  gx_utility_ltoa(rpm_current, (GX_CHAR *)current_rpm_string, 10);
                    	  gx_prompt_text_set(&main_screen.main_screen_rpm_current_disp, (GX_CHAR *)current_rpm_string);
                    	  }

                    	if(rpm_current<2500 && rpm_current>=1500)
                    	  {

                    	  gx_prompt_text_color_set(&main_screen.main_screen_rpm_current_disp, GX_COLOR_ID_YELLOW,GX_COLOR_ID_YELLOW);
                    	  gx_utility_ltoa(rpm_current, (GX_CHAR *)current_rpm_string, 10);
                    	  gx_prompt_text_set(&main_screen.main_screen_rpm_current_disp, (GX_CHAR *)current_rpm_string);

                    	 }

                       if(rpm_current<=1499 )
                    	  {

                    	  gx_prompt_text_color_set(&main_screen.main_screen_rpm_current_disp, GX_COLOR_ID_GREEN,GX_COLOR_ID_GREEN);
                    	  gx_utility_ltoa(rpm_current, (GX_CHAR *)current_rpm_string, 10);
                    	  gx_prompt_text_set(&main_screen.main_screen_rpm_current_disp, (GX_CHAR *)current_rpm_string);
                    	  }

                       //DUTY CYCLE DISPLAY VALUE SELECCION

                       if(rpm_duty_copy>=70)
                         {

                    	 gx_prompt_text_color_set(&main_screen.main_screen_pwm_duty,GX_COLOR_ID_ID_RED,GX_COLOR_ID_ID_RED);
                    	 gx_utility_ltoa(rpm_duty_copy, (GX_CHAR *)rpm_pwm_duty_string, 10);
                    	 gx_prompt_text_set(&main_screen.main_screen_pwm_duty, (GX_CHAR *)rpm_pwm_duty_string);

                         }

                       if(rpm_duty_copy<70 && rpm_duty_copy>=40)
                         {

                    	 gx_prompt_text_color_set(&main_screen.main_screen_pwm_duty, GX_COLOR_ID_YELLOW,GX_COLOR_ID_YELLOW);
                    	 gx_utility_ltoa(rpm_duty_copy, (GX_CHAR *)rpm_pwm_duty_string, 10);
                    	 gx_prompt_text_set(&main_screen.main_screen_pwm_duty, (GX_CHAR *)rpm_pwm_duty_string);

                         }

                       if(rpm_duty_copy<=39 )
                         {

                         gx_prompt_text_color_set(&main_screen.main_screen_pwm_duty, GX_COLOR_ID_GREEN,GX_COLOR_ID_GREEN);
                         gx_utility_ltoa(rpm_duty_copy, (GX_CHAR *)rpm_pwm_duty_string, 10);
                         gx_prompt_text_set(&main_screen.main_screen_pwm_duty, (GX_CHAR *)rpm_pwm_duty_string);

                         }


                    	//g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_14, on);

                    	 	//on=!on;
                       //rpm_pwm_duty=100+rpm_pwm_duty;
                    	                gx_system_event_send(&gxe);

                    	                rpm_current=0;
                    	                IT0=IT;

                    }


                    if (SF_MESSAGE_EVENT_READ_RPM_TEST == p_message->event_b.code)
                                        {
                    	//gx_system_widget_find(ID_POPO, GX_SEARCH_DEPTH_INFINITE, (GX_WIDGET **) &prompt);
                    	rpm_current++;
                        //rpm_pwm_duty++;

                        //gx_system_widget_find(ID_POPO, GX_SEARCH_DEPTH_INFINITE, (GX_WIDGET **) &prompt);
                        //gx_widget_find(&main_screen, ID_POPO, 3, (GX_WIDGET **) &prompt);
                       // gx_utility_ltoa(rpm_pwm_duty, (GX_CHAR *)target_temp_string, 10);
                       // gx_prompt_text_set(&main_screen.main_screen_popo, (GX_CHAR *)target_temp_string);

                                        	                //gx_system_event_send(&gxe);
                                        	                //rpm_test=rpm_test+1;

                                        }

                    if (SF_MESSAGE_EVENT_PWM_DUTY_CYCLE_UPDATE == p_message->event_b.code)
                      {
                    	//rpm_pwm_duty=rpm_pwm_duty+2;
                    	//gx_system_widget_find(ID_POPO, GX_SEARCH_DEPTH_INFINITE, (GX_WIDGET **) &prompt);
                    	  //        	gx_utility_ltoa(rpm_pwm_duty, (GX_CHAR *)target_temp_string, 10);
                    	    //                    gx_prompt_text_set(&main_screen.main_screen_popo, (GX_CHAR *)target_temp_string);

                    	      //                                  	                gx_system_event_send(&gxe);
                    	                                        	                //err = g_sf_message.p_api->bufferRelease(g_sf_message.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_NONE);
                                                            }



                    break;


        default:
            break;
        }

        /** Message is processed, so release buffer. */
        err = g_sf_message.p_api->bufferRelease(g_sf_message.p_ctrl, (sf_message_header_t *) p_message, SF_MESSAGE_RELEASE_OPTION_NONE);
        if (err)
        {
            while(1)
            {;}
        }
    }
}


/*******************************************************************************************************************//**
 * @brief  Sends a touch event to GUIX internal thread to call the GUIX event handler function
 *
 * @param[in] p_payload Touch panel message payload
***********************************************************************************************************************/
static void hmi_send_touch_message(sf_touch_panel_payload_t * p_payload)
{
    bool send_event = true;
    GX_EVENT gxe;

    switch (p_payload->event_type)
    {

    case SF_TOUCH_PANEL_EVENT_DOWN:
    	//g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_14, true);

        gxe.gx_event_type = GX_EVENT_PEN_DOWN;
        break;
    case SF_TOUCH_PANEL_EVENT_UP:
    	//g_ioport.p_api->pinWrite(IOPORT_PORT_01_PIN_14, true);
    	//gx_prompt_text_set(&main_screen.main_screen_dutycycle, "dos");
        gxe.gx_event_type = GX_EVENT_PEN_UP;
        break;
    case SF_TOUCH_PANEL_EVENT_HOLD:
    case SF_TOUCH_PANEL_EVENT_MOVE:
        gxe.gx_event_type = GX_EVENT_PEN_DRAG;
        break;
    case SF_TOUCH_PANEL_EVENT_INVALID:
        send_event = false;
        break;
    default:
        break;
    }

    if (send_event)
    {
        /** Send event to GUI */
        gxe.gx_event_sender         = GX_ID_NONE;
        gxe.gx_event_target         = 0;  /* the event to be routed to the widget that has input focus */
        gxe.gx_event_display_handle = 0;

        gxe.gx_event_payload.gx_event_pointdata.gx_point_x = p_payload->x;
#if defined(BSP_BOARD_S7G2_SK)||defined(BSP_BOARD_S5D9_PK)
        gxe.gx_event_payload.gx_event_pointdata.gx_point_y = (GX_VALUE)(320 - p_payload->y);
#else
        gxe.gx_event_payload.gx_event_pointdata.gx_point_y = p_payload->y;
#endif

        gx_system_event_send(&gxe);
    }
}

#if defined(BSP_BOARD_S7G2_SK)||defined(BSP_BOARD_S5D9_PK)
void g_lcd_spi_callback(spi_callback_args_t * p_args)
{
    if (p_args->event == SPI_EVENT_TRANSFER_COMPLETE)
        tx_semaphore_ceiling_put(&g_hmi_semaphore_lcdc, 1);

}
#endif
