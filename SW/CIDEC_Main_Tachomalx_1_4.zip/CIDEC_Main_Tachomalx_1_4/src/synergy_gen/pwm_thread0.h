/* generated thread header file - do not edit */
#ifndef PWM_THREAD0_H_
#define PWM_THREAD0_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
extern "C" void pwm_thread0_entry(void);
#else
extern void pwm_thread0_entry(void);
#endif
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* PWM_THREAD0_H_ */
