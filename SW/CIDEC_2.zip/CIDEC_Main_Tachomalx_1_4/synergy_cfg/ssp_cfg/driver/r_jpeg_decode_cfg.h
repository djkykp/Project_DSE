/* generated configuration header file - do not edit */
#ifndef R_JPEG_DECODE_CFG_H_
#define R_JPEG_DECODE_CFG_H_
#define JPEG_DECODE_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* R_JPEG_DECODE_CFG_H_ */
