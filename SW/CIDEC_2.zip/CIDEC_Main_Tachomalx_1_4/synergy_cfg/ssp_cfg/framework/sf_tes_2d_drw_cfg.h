/* generated configuration header file - do not edit */
#ifndef SF_TES_2D_DRW_CFG_H_
#define SF_TES_2D_DRW_CFG_H_
#define SF_TES_2D_DRW_D1_HEAP_SIZE (32768)
#define SF_TES_2D_DRW_CFG_IRQ_IPL  ((3))
#endif /* SF_TES_2D_DRW_CFG_H_ */
